# RC Spell Audit → Averathia Spell Set — v1.0.5

Scope: RC spell levels 1–3 for the current Cleric and Arcanist/Elf spellcasting paths.

Classification rule:
- NOW = deterministic effect can be represented by Averathia's current combat/HP/save/buff state.
- LATER = useful spell, but requires a missing world/event/targeting/inventory/stealth/detection subsystem.
- NO = fundamentally unsuitable for Averathia's format. None of the level 1–3 spells were rejected outright in this first pass; many are deferred instead.

Important: this audit does not claim that every NOW spell is already implemented. It defines the implementation set for the next spell-mechanics pass.

## Arcanist/Elf
### Spell level 1
- NOW: Magic Missile, Shield, Sleep, Light
- LATER: Charm Person, Detect Magic, Floating Disc, Hold Portal, Read Languages, Read Magic, Ventriloquism
- NO: —

### Spell level 2
- NOW: Mirror Image, Web
- LATER: Continual Light, Detect Evil, Detect Invisible, ESP, Invisibility, Knock, Levitate, Locate Object, Wizard Lock
- NO: —

### Spell level 3
- NOW: Fireball, Lightning Bolt, Haste, Slow, Hold Person, Protection from Normal Missiles
- LATER: Clairvoyance, Create Air, Dispel Magic, Fly, Infravision, Invisibility 10' Radius, Water Breathing
- NO: —

## Cleric
### Spell level 1
- NOW: Cure Light Wounds, Protection from Evil, Remove Fear, Resist Cold
- LATER: Detect Evil, Detect Magic, Light, Purify Food and Water
- NO: —

### Spell level 2
- NOW: Bless, Hold Person, Resist Fire
- LATER: Find Traps, Know Alignment, Silence 15' Radius, Snake Charm, Speak with Animal
- NO: —

### Spell level 3
- NOW: Cure Disease, Striking
- LATER: Continual Light, Cure Blindness, Dispel Magic, Growth of Animals, Locate Object, Speak with the Dead
- NO: —
